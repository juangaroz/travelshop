
  # TravelShop Partner Portal Prototype

  This is a code bundle for TravelShop Partner Portal Prototype. The original project is available at https://www.figma.com/design/WVncfH9PQW6kcl2vXAuMoL/TravelShop-Partner-Portal-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  